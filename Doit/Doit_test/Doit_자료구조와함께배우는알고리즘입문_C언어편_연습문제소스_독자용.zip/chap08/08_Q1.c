﻿///* Q1 널문자 대입 확인하기 */
//#include <stdio.h>
//
//int main(void)
//{
//	char st[10];
//
//	st[0] = 'A';
//	st[1] = 'B';
//	st[2] = 'C';
//	st[3] = 'D';
//	st[4] = '\0';
//
//	st[5] = 'E';
//	st[6] = 'F';
//	st[7] = 'G';
//	st[8] = 'H';
//	st[9] = 'I';
//
//	printf("문자열 st에는 \"%s\"가 포함되어 있습니다.\n", st);
//
//	return 0;
//}
